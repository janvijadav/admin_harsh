<?php
/*-------------------------------------------------------+
| File Upload In PHP With Database
| http://www.kvcodes.com/
+--------------------------------------------------------+
| Author: Varadha  
| Email: admin@kvcodes.com
+--------------------------------------------------------+*/
$kv = new mysqli('localhost', 'root', '123', 'Kvcodes_Demo');

if ($kv->connect_error) { // Check connection
 die("Connection failed: " . $kv->connect_error);
} 

if(isset($_FILES["attachment"]["error"])){
   if($_FILES["attachment"]["error"] > 0){
      echo "Error: ".$_FILES["attachment"]["error"]; 
   }else {
   	
	// File Type Restrictions
	$filename = $_FILES["attachment"]["name"];
	$allowed = array( 'jpg', 'jpeg', 'gif', 'png', 'bmp');
	$ext = pathinfo($filename, PATHINFO_EXTENSION); 
	if(!in_array($ext, $allowed)) 
		die("Error: Please select a valid file format.-".$ext);
	
	// File size Resctrictions
	$maxsize = 2 * 1024 * 1024; //2MB maximum allowed.
	$filesize= $_FILES["attachment"]["size"];
	if($filesize > $maxsize) 
		die("Error: File size is larger than the allowed limit.");
		
    $uploads_dir = "uploads/";
    if(file_exists($uploads_dir. $_FILES["attachment"]["name"])){ 
        echo $_FILES["attachment"]["name"] . " is already exists. Please Rename and Upload it again"; 
    } else{   
		move_uploaded_file($_FILES["attachment"]["tmp_name"], $uploads_dir. $_FILES["attachment"]["name"]); 
		mysqli_query($kv, "INSERT INTO kv_images (filename, type, size, date) values ( '".$_FILES["attachment"]["name"]."', '".$_FILES["attachment"]["type"]."', '".$_FILES["attachment"]["size"]."', '".date('Y-m-d')."')");
		if(mysqli_insert_id($kv)){
			echo ' Successfully Inserted #'.mysqli_insert_id($kv); 
		}		
	}
 }
} 

$kv->close();

?>