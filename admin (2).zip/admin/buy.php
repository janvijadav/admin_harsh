<?php
require "header.php";
?>





  <!-- health section -->

  <section class="health_section layout_padding">
    <div class="health_carousel-container">
      <h2 class="text-uppercase">
        Medicine & Health

      </h2>
      <div class="carousel-wrap layout_padding2">
        <div class="owl-carousel">
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-1.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    30
                  </h6>
                </div>
              </div>
            </div>
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-5.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    30
                  </h6>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-2.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    31
                  </h6>
                </div>
              </div>
            </div>
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-5.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    34
                  </h6>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-3.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    37
                  </h6>
                </div>
              </div>
            </div>
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-5.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    30
                  </h6>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-4.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    64
                  </h6>
                </div>
              </div>
            </div>
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-5.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Health
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    55
                  </h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="health_carousel-container">
      <h2 class="text-uppercase">
        Vitamins & Supplements


      </h2>
      <div class="carousel-wrap layout_padding2">
        <div class="owl-carousel owl-2">
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-6.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Medicine
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    36
                  </h6>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-6.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Medicine
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    75
                  </h6>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-6.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Medicine
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    60
                  </h6>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="btn_container">
                <a href="w.php">
                  Buy Now
                </a>
              </div>
              <div class="img-box">
                <img src="images/p-6.jpg" alt="">
              </div>
              <div class="detail-box">
                <div class="star_container">
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star-o" aria-hidden="true"></i>

                </div>
                <div class="text">
                  <h6>
                    Medicine
                  </h6>
                  <h6 class="price">
                    <span>
                      Rs.
                    </span>
                    35
                  </h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="d-flex justify-content-center">
      <a href="">
        See more
      </a>
    </div>
  </section>

  <!-- end health section -->


<?php  
require "footer.php";
?>