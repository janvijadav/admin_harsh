
</html>
<a href="https://wa.me/916355866936?text=Hi%20There!"
class="float"
style="
  position: fixed;
  width: 50px;
  height: 50px;
  bottom: 70px;
  right: 120px;
  color: #fff;
  border-radius: 50px;
  text-align: center;
  cursor: pointer;
  box-shadow: 2px 2px 3px #999;
"
>
<img
  src="https://trickuweb.com/whatsapp.png"
  alt=""
  height="60px"
  width="60px"
/>
</a>